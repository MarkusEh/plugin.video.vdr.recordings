# plugin.video.vdr.recordings
Play VDR recordings in KODI. VDR itself is not required.

Installation:

Download the plugin.video.vdr.recordings.\<version\>.zip file from this git. (Don't use the github functionality to create a zip from this repository, KODI will not install this).
  
Install the plugin from the downloaded zip file in KODI. Note: You have to allow plugins from unsecure sources first.

Setup:

Maintain the folder with the VDR recordings in the plugin settings

End user documantation: https://github.com/MarkusEh/plugin.video.vdr.recordings/wiki
